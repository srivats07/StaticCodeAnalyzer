﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticTester
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string msg = Console.ReadLine();
            Console.WriteLine(msg);
            
        }
        private void Tester()
        {
        }
        
    }
}
