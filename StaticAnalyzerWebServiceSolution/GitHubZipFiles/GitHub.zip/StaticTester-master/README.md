# StaticTester
For Testing purpose
Maximum accepted error : 3
Maximum accepted warning : 3 

